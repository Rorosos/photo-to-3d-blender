"""Language selection for the add-on, independently of Blender's UI locale."""

from pathlib import Path

import bpy


BRAND = "Photo to 3D"
LANGUAGES = {
    "ru": "Русский", "en": "English", "zh": "简体中文", "hi": "हिन्दी",
    "es": "Español", "ar": "العربية", "fr": "Français", "bn": "বাংলা",
    "pt": "Português", "id": "Bahasa Indonesia", "ur": "اردو", "de": "Deutsch",
}

with Path(__file__).with_name("translations.tsv").open(encoding="utf-8") as stream:
    codes = next(stream).strip().split("|")
    MESSAGES = {}
    for line in stream:
        values = line.rstrip("\r\n").split("|")
        MESSAGES[values[0]] = dict(zip(codes, values, strict=True))


def preferences():
    addon = bpy.context.preferences.addons.get(__package__)
    return addon.preferences if addon else None


def language():
    choice = getattr(preferences(), "language", "auto")
    if choice == "auto":
        choice = bpy.app.translations.locale.partition("_")[0]
    return choice if choice in LANGUAGES else "en"


def translate(message, code=None):
    active = code or language()
    if active == "ru":
        return message
    values = MESSAGES.get(message)
    return values.get(active, values["en"]) if values else message
