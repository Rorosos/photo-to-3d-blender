"""Convert the engines' intermediate GLB into a portable FBX result."""

from pathlib import Path
import sys

import bpy
from mathutils import Vector


def export_fbx(source, destination):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=str(source))
    meshes = [obj for obj in bpy.context.scene.objects if obj.type == "MESH"]
    if not meshes:
        raise ValueError("Движок вернул пустую сцену")

    external = {}
    for material in bpy.data.materials:
        if not material.node_tree:
            continue
        for node in material.node_tree.nodes:
            image = node.image if node.type == "TEX_IMAGE" else None
            if not image or not image.packed_file:
                continue
            if image in external:
                node.image = external[image]
                continue
            data = image.packed_file.data
            downstream = [link for output in node.outputs for link in output.links]
            roles = {link.to_socket.name for link in downstream}
            if "Base Color" in roles:
                name = "BaseColor"
            elif any(link.to_node.type == "NORMAL_MAP" for link in downstream):
                name = "Normal"
            elif any(link.to_node.type in {"SEPARATE_COLOR", "SEPRGB"} for link in downstream):
                name = "Metallic-Roughness"
            else:
                name = "Texture"
            texture_dir = destination / "Textures"
            texture_dir.mkdir(exist_ok=True)
            suffix = ".jpg" if data.startswith(b"\xff\xd8") else ".png"
            path = texture_dir / (name + suffix)
            index = 2
            while path.exists():
                path = texture_dir / f"{name}-{index}{suffix}"
                index += 1
            path.write_bytes(data)
            reloaded = bpy.data.images.load(str(path))
            reloaded.colorspace_settings.name = image.colorspace_settings.name
            external[image] = reloaded
            node.image = reloaded

    result = bpy.ops.export_scene.fbx(
        filepath=str(destination / "model.fbx"), path_mode="RELATIVE",
        embed_textures=False, bake_anim=False,
    )
    if result != {"FINISHED"}:
        raise RuntimeError("Blender не сохранил FBX")
    return meshes


def render_preview(meshes, destination):
    points = [obj.matrix_world @ Vector(p) for obj in meshes for p in obj.bound_box]
    lower = Vector(tuple(min(p[i] for p in points) for i in range(3)))
    upper = Vector(tuple(max(p[i] for p in points) for i in range(3)))
    center = (lower + upper) / 2
    extent = max(max(upper - lower), 0.001)
    scene = bpy.context.scene
    camera = bpy.data.cameras.new("Preview")
    view = bpy.data.objects.new("Preview", camera)
    scene.collection.objects.link(view)
    scene.camera = view
    view.location = center + Vector((1.2, -2, 0.9)) * extent
    view.rotation_euler = (center - view.location).to_track_quat("-Z", "Y").to_euler()
    camera.type = "ORTHO"
    camera.ortho_scale = extent * 1.45
    scene.render.engine = "BLENDER_WORKBENCH"
    shading = scene.display.shading
    shading.light = "STUDIO"
    shading.color_type = "TEXTURE"
    shading.background_type = "WORLD"
    scene.world = bpy.data.worlds.new("Preview")
    scene.world.color = (0.12, 0.14, 0.17)
    scene.render.resolution_x = scene.render.resolution_y = 256
    scene.render.resolution_percentage = 100
    scene.render.filepath = str(destination / "preview.png")
    bpy.ops.render.render(write_still=True)


def export(source, destination):
    destination.mkdir(parents=True, exist_ok=True)
    meshes = export_fbx(source, destination)
    render_preview(meshes, destination)


if __name__ == "__main__":
    source, destination = map(Path, sys.argv[sys.argv.index("--") + 1:])
    export(source.resolve(), destination.resolve())
