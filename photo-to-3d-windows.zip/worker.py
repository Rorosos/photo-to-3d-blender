"""Local worker. Invoked with the selected engine's Python interpreter."""
import gc
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path

from state import ROOT, database, extended_path, gpu_lock, jobdir, report_progress, update
from model_weights import missing
from component_catalog import BUNDLED_MODELS, components_for, has_bundled_weights, missing_components, weight_files


def images_for(s):
    from PIL import Image, ImageOps
    images = {}
    session = None
    for view, path in s["images"].items():
        with Image.open(path) as source:
            image = ImageOps.exif_transpose(source).convert("RGBA")
        alpha = image.getchannel("A")
        if s["background"] and alpha.getextrema()[0] == 255 and s["engine"] != "trellis":
            import rembg
            if session is None:
                session = rembg.new_session("u2netp", providers=["CPUExecutionProvider"])
            image = rembg.remove(image, session=session)
        if image.getchannel("A").getbbox() is None:
            raise ValueError("После удаления фона изображение пустое")
        images[view] = image
    return images


def hunyuan(s, images, path, stage):
    import torch
    from hy3dgen.shapegen import Hunyuan3DDiTFlowMatchingPipeline, FaceReducer
    name = "mv" if len(images) > 1 else "mini"
    stage("Загрузка Hunyuan3D-2" + name, 0.10)
    pipe = Hunyuan3DDiTFlowMatchingPipeline.from_pretrained(
        "tencent/Hunyuan3D-2" + name, subfolder="hunyuan3d-dit-v2-" + name + "-turbo",
        device="cpu", use_safetensors=True)
    # Move the three large networks one at a time, including the VAE's custom decode path.
    pipe.device = torch.device("cuda")
    pipe.conditioner.to("cuda")
    def next_stage(module, inputs):
        pipe.conditioner.cpu()
        module.to("cuda")
        shape_hook.remove()
    def decode_stage(module, inputs):
        pipe.model.cpu()
        module.to("cuda")
        vae_hook.remove()
    shape_hook = pipe.model.register_forward_pre_hook(next_stage)
    vae_hook = pipe.vae.register_forward_pre_hook(decode_stage)
    steps = 5
    shape_end = 0.58 if s["paint"] else 0.78

    def shape_progress(index, timestep, output):
        done = min(index + 1, steps)
        stage("Восстановление формы", 0.20 + (shape_end - 0.20) * done / steps, (done, steps))

    stage("Восстановление формы", 0.20, (0, steps))
    with torch.inference_mode():
        mesh = pipe(image=images if len(images) > 1 else images["front"],
                    num_inference_steps=steps, guidance_scale=0,
                    callback=shape_progress, callback_steps=1,
                    generator=torch.Generator(device="cuda").manual_seed(s["seed"]),
                    num_chunks=2048, octree_resolution=s["detail"], mc_algo="mc")[0]
    del pipe
    gc.collect()
    torch.cuda.empty_cache()
    if len(mesh.faces) > s["target"] * 2:
        stage("Упрощение сетки", shape_end + 0.03)
        mesh = FaceReducer()(mesh, max_facenum=s["target"] * 2)
    mesh.export(path, file_type="glb")
    if not s["paint"]:
        return "Только геометрия"
    stage("Hunyuan Paint", 0.67)
    try:
        from hy3dgen.texgen import Hunyuan3DPaintPipeline
        paint = Hunyuan3DPaintPipeline.from_pretrained("tencent/Hunyuan3D-2")
        paint.config.texture_size = s["texture"]
        paint.config.render_size = min(1024, s["texture"])
        paint.render.set_default_texture_resolution(s["texture"])
        paint.render.set_default_render_resolution(paint.config.render_size)
        paint.enable_model_cpu_offload()
        stage("Запекание текстуры · Hunyuan Paint", 0.78)
        painted = paint(mesh, image=images["front"])
        stage("Сохранение текстуры", 0.91)
        painted.export(path.with_name("paint.glb"))
        path.with_name("paint.glb").replace(path)
        return "Hunyuan Paint · текстура"
    except Exception as exc:
        traceback.print_exc()
        return "Только геометрия · Paint: " + str(exc)[:180]


def birefnet_cutout(image):
    import torch
    from PIL import Image
    from torchvision.transforms import Compose, Normalize, Resize, ToTensor
    from transformers import AutoModelForImageSegmentation

    model = AutoModelForImageSegmentation.from_pretrained(
        str(extended_path(ROOT / "models" / "birefnet")), local_files_only=True,
        trust_remote_code=True, dtype=torch.float16,
    ).eval().to("cuda")
    transform = Compose([
        Resize((1024, 1024)), ToTensor(),
        Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
    ])
    pixels = transform(image.convert("RGB")).unsqueeze(0).to("cuda", torch.float16)
    with torch.inference_mode():
        alpha = model(pixels)[-1][0, 0].float().sigmoid().mul(255).round().byte().cpu().numpy()
    mask = Image.fromarray(alpha).resize(image.size, Image.Resampling.BILINEAR)
    if mask.getextrema()[1] <= 204:
        raise ValueError("BiRefNet не нашёл объект на фотографии")
    image.putalpha(mask)
    return image


def track_sampler(sampler, steps, stage, message, start, end):
    sample_once = sampler.sample_once
    done = 0

    def step(*args, **kwargs):
        nonlocal done
        if not done:
            stage(message, start, (0, steps))
        result = sample_once(*args, **kwargs)
        done = min(done + 1, steps)
        stage(message, start + (end - start) * done / steps, (done, steps))
        return result

    sampler.sample_once = step


def trellis(s, images, path, stage):
    import torch

    os.environ.update(TRELLIS_MAX_RESOLUTION="512", OPENCV_IO_ENABLE_OPENEXR="1",
                      TRELLIS_NO_REMBG="1",
                      ATTN_BACKEND="xformers", SPARSE_ATTN_BACKEND="xformers")
    image = images["front"]
    if s["background"] and image.getchannel("A").getextrema()[0] == 255:
        stage("Удаление фона · BiRefNet", 0.05)
        image = birefnet_cutout(image)
        torch.cuda.empty_cache()
    from pipeline_worker import _apply_patches
    _apply_patches()
    from trellis2.pipelines import Trellis2ImageTo3DPipeline
    import o_voxel
    install_bundled_weights(s, stage)
    stage("Загрузка TRELLIS.2", 0.12)
    pipe = Trellis2ImageTo3DPipeline.from_pretrained(str(ROOT/"models"/"trellis"))
    pipe.low_vram = True
    pipe.cuda()
    steps = s.get("steps", 12)
    track_sampler(pipe.sparse_structure_sampler, steps, stage, "Генерация структуры", 0.22, 0.36)
    track_sampler(pipe.shape_slat_sampler, steps, stage, "Восстановление формы", 0.39, 0.57)
    track_sampler(pipe.tex_slat_sampler, steps, stage, "Генерация материалов", 0.60, 0.77)
    preprocess = image.getchannel("A").getextrema()[0] < 255
    mesh = pipe.run(image if preprocess else image.convert("RGB").resize((512,512)),
                    sparse_structure_sampler_params={"steps":steps},
                    shape_slat_sampler_params={"steps":steps},
                    tex_slat_sampler_params={"steps":steps},
                    seed=s["seed"], pipeline_type="512", preprocess_image=preprocess)[0]
    stage("UV и запекание материалов", 0.84)
    glb = o_voxel.postprocess.to_glb(vertices=mesh.vertices, faces=mesh.faces,
        attr_volume=mesh.attrs, coords=mesh.coords, attr_layout=mesh.layout,
        voxel_size=mesh.voxel_size, aabb=[[-0.5]*3,[0.5]*3],
        decimation_target=s["target"]*2, texture_size=s["texture"],
        remesh=True, remesh_band=1, remesh_project=0, verbose=False)
    glb.export(path, file_type="glb")
    return "UV и текстура PBR"


def install_bundled_weights(spec, stage):
    """Make bundled auxiliary files visible to the Windows TRELLIS runtime."""
    for group in components_for(spec):
        if not has_bundled_weights(group):
            continue
        files = missing(ROOT, weight_files(group))
        if files:
            stage("Подготовка встроенной модели · DINOv3")
        for record in files:
            relative = Path(record["path"])
            source = BUNDLED_MODELS / relative.relative_to("trellis/src/MODELS")
            target = ROOT / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.with_name(target.name + ".bundled.part")
            temporary.unlink(missing_ok=True)
            try:
                os.link(source, temporary)
            except OSError:
                shutil.copyfile(source, temporary)
            temporary.replace(target)


def run(job_id):
    with gpu_lock() as free:
        if not free:
            return
        with database() as db:
            row = db.execute("SELECT id,spec FROM jobs WHERE status='waiting' ORDER BY id LIMIT 1").fetchone()
            if not row or row["id"] != job_id:
                return
            db.execute("UPDATE jobs SET status='running',note='Подготовка',progress=NULL WHERE id=?", (job_id,))
        start = time.monotonic()
        stop = threading.Event()
        device_peak = [0]
        exporter = None
        def watch():
            import ctypes as ct
            try:
                nvml = ct.WinDLL("nvml.dll")
                device = ct.c_void_p()
                memory = (ct.c_ulonglong * 3)()
                if nvml.nvmlInit_v2() or nvml.nvmlDeviceGetHandleByIndex_v2(0,ct.byref(device)):
                    nvml = None
            except OSError:
                nvml = None
            while not stop.wait(0.35):
                if nvml and not nvml.nvmlDeviceGetMemoryInfo(device,ct.byref(memory)):
                    device_peak[0] = max(device_peak[0],memory[2]/1048576)
                with database() as db:
                    status = db.execute("SELECT status FROM jobs WHERE id=?", (job_id,)).fetchone()[0]
                if status == "cancelling":
                    if exporter is not None and exporter.poll() is None:
                        exporter.terminate()
                    update(job_id, "cancelled", "Отменено", time.monotonic()-start)
                    os._exit(2)
        threading.Thread(target=watch, daemon=True).start()
        last_message = None
        fraction = 0.0

        def stage(message, value=None, steps=None):
            nonlocal last_message, fraction
            if message != last_message:
                print(message, flush=True)
                last_message = message
            if value is not None:
                fraction = max(fraction, value)
            report_progress(job_id, message, generation=fraction, steps=steps)
        try:
            s = json.loads(row["spec"])
            src = ROOT / s["engine"] / "src"
            os.chdir(src)
            packages = Path(sys.prefix) / "Lib" / "site-packages"
            sys.path[:0] = [str(extended_path(src)), str(extended_path(packages))]
            os.environ.update(HF_MODULES_CACHE=str(ROOT/"cache"/"hfmodules"), HY3DGEN_MODELS=str(ROOT/"models"), HF_HUB_CACHE=str(ROOT/"cache"/"hub"),
                              U2NET_HOME=str(ROOT/"models"/"rembg"), TORCH_HOME=str(ROOT/"cache"/"torch"),
                              NUMBA_CACHE_DIR=str(extended_path(ROOT / "cache" / "numba")))
            if missing_components(ROOT, components_for(s)):
                raise RuntimeError("Отсутствуют компоненты. Нажмите «Скачать модель и движок» в Blender")
            import torch
            if not torch.cuda.is_available():
                raise RuntimeError("PyTorch не видит CUDA в окружении движка")
            torch.cuda.reset_peak_memory_stats()
            stage("Подготовка изображений", 0.02)
            folder = jobdir(job_id)
            folder.mkdir(parents=True, exist_ok=True)
            path = folder / "building.glb"
            note = {"hunyuan": hunyuan, "trellis": trellis}[s["engine"]](s, images_for(s), path, stage)
            with path.open("rb") as f:
                if f.read(4) != b"glTF":
                    raise ValueError("Движок вернул повреждённый GLB")
            gc.collect()
            torch.cuda.empty_cache()
            stage("Экспорт FBX и миниатюры", 0.95)
            staging = folder / "exporting"
            blender = os.environ["PHOTO3D_BLENDER"]
            script = Path(__file__).resolve().with_name("export_result.py")
            exporter = subprocess.Popen([
                blender, "-b", "--factory-startup", "--offline-mode",
                "--python-exit-code", "1", "--python", str(script),
                "--", str(path), str(staging),
            ])
            if exporter.wait() != 0:
                raise RuntimeError("Не удалось сохранить FBX и миниатюру. Подробности в run.log")
            textures = staging / "Textures"
            if textures.exists():
                textures.rename(folder / textures.name)
            (staging / "preview.png").replace(folder / "preview.png")
            (staging / "model.fbx").replace(folder / "model.fbx")
            staging.rmdir()
            path.unlink()
            stop.set()
            (folder/"metrics.json").write_text(json.dumps({"seconds":time.monotonic()-start,
                "peak_card_mib":device_peak[0],"peak_torch_mib":torch.cuda.max_memory_reserved()/1048576,
                "device":torch.cuda.get_device_name(),"settings":s},ensure_ascii=False,indent=2),encoding="utf-8")
            with database() as db:
                db.execute("""UPDATE jobs SET status=CASE WHEN status='cancelling' THEN 'cancelled' ELSE 'done' END,
                           progress=CASE WHEN status='cancelling' THEN progress ELSE ? END,
                           note=?,elapsed=?,peak=? WHERE id=?""",
                           (json.dumps({"generation": 1.0}), note, time.monotonic()-start,
                            torch.cuda.max_memory_reserved()/1048576,job_id))
        except Exception as exc:
            traceback.print_exc()
            update(job_id, "error", str(exc)[:450], time.monotonic()-start)
        finally:
            stop.set()

if __name__ == "__main__":
    run(int(sys.argv[1]))




