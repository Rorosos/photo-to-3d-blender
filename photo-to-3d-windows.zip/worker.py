"""Local worker. Invoked with the selected engine's Python interpreter."""
import gc
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path

from state import ROOT, database, gpu_lock, jobdir, update
from model_weights import missing
from component_catalog import BUNDLED_MODELS, components_for, has_bundled_weights, missing_components, weight_files


def images_for(s):
    from PIL import Image, ImageOps
    images = {}
    session = None
    for view, path in s["images"].items():
        with Image.open(path) as source:
            image = ImageOps.exif_transpose(source).convert("RGBA")
        alpha = image.getchannel("A")
        if s["background"] and alpha.getextrema()[0] == 255 and s["engine"] != "trellis":
            import rembg
            if session is None:
                session = rembg.new_session("u2netp", providers=["CPUExecutionProvider"])
            image = rembg.remove(image, session=session)
        if image.getchannel("A").getbbox() is None:
            raise ValueError("После удаления фона изображение пустое")
        images[view] = image
    return images


def hunyuan(s, images, path, stage):
    import torch
    from hy3dgen.shapegen import Hunyuan3DDiTFlowMatchingPipeline, FaceReducer
    name = "mv" if len(images) > 1 else "mini"
    stage("Загрузка Hunyuan3D-2" + name)
    pipe = Hunyuan3DDiTFlowMatchingPipeline.from_pretrained(
        "tencent/Hunyuan3D-2" + name, subfolder="hunyuan3d-dit-v2-" + name + "-turbo",
        device="cpu", use_safetensors=True)
    # Move the three large networks one at a time, including the VAE's custom decode path.
    pipe.device = torch.device("cuda")
    pipe.conditioner.to("cuda")
    def next_stage(module, inputs):
        pipe.conditioner.cpu()
        module.to("cuda")
        shape_hook.remove()
    def decode_stage(module, inputs):
        pipe.model.cpu()
        module.to("cuda")
        vae_hook.remove()
    shape_hook = pipe.model.register_forward_pre_hook(next_stage)
    vae_hook = pipe.vae.register_forward_pre_hook(decode_stage)
    stage("Восстановление формы")
    with torch.inference_mode():
        mesh = pipe(image=images if len(images) > 1 else images["front"],
                    num_inference_steps=5, guidance_scale=0,
                    generator=torch.Generator(device="cuda").manual_seed(s["seed"]),
                    num_chunks=2048, octree_resolution=s["detail"], mc_algo="mc")[0]
    del pipe
    gc.collect()
    torch.cuda.empty_cache()
    if len(mesh.faces) > s["target"] * 2:
        stage("Упрощение сетки")
        mesh = FaceReducer()(mesh, max_facenum=s["target"] * 2)
    mesh.export(path, file_type="glb")
    if not s["paint"]:
        return "Только геометрия"
    stage("Hunyuan Paint")
    try:
        from hy3dgen.texgen import Hunyuan3DPaintPipeline
        paint = Hunyuan3DPaintPipeline.from_pretrained("tencent/Hunyuan3D-2")
        paint.config.texture_size = s["texture"]
        paint.config.render_size = min(1024, s["texture"])
        paint.render.set_default_texture_resolution(s["texture"])
        paint.render.set_default_render_resolution(paint.config.render_size)
        paint.enable_model_cpu_offload()
        painted = paint(mesh, image=images["front"])
        painted.export(path.with_name("paint.glb"))
        path.with_name("paint.glb").replace(path)
        return "Hunyuan Paint · текстура"
    except Exception as exc:
        traceback.print_exc()
        return "Только геометрия · Paint: " + str(exc)[:180]


def trellis(s, images, path, stage):
    os.environ.update(TRELLIS_MAX_RESOLUTION="512", OPENCV_IO_ENABLE_OPENEXR="1",
                      TRELLIS_NO_REMBG="0" if s["background"] else "1",
                      ATTN_BACKEND="xformers", SPARSE_ATTN_BACKEND="xformers")
    from pipeline_worker import _apply_patches
    _apply_patches()
    from trellis2.pipelines import Trellis2ImageTo3DPipeline
    import o_voxel
    install_bundled_weights(s, stage)
    stage("Загрузка TRELLIS.2")
    pipe = Trellis2ImageTo3DPipeline.from_pretrained(str(ROOT/"models"/"trellis"))
    pipe.low_vram = True
    pipe.cuda()
    stage("Генерация 512³")
    image = images["front"]
    preprocess = s["background"] or image.getchannel("A").getextrema()[0] < 255
    mesh = pipe.run(image if preprocess else image.convert("RGB").resize((512,512)),
                    sparse_structure_sampler_params={"steps":s.get("steps",12)},
                    shape_slat_sampler_params={"steps":s.get("steps",12)},
                    tex_slat_sampler_params={"steps":s.get("steps",12)},
                    seed=s["seed"], pipeline_type="512", preprocess_image=preprocess)[0]
    stage("UV и запекание материалов")
    glb = o_voxel.postprocess.to_glb(vertices=mesh.vertices, faces=mesh.faces,
        attr_volume=mesh.attrs, coords=mesh.coords, attr_layout=mesh.layout,
        voxel_size=mesh.voxel_size, aabb=[[-0.5]*3,[0.5]*3],
        decimation_target=s["target"]*2, texture_size=s["texture"],
        remesh=True, remesh_band=1, remesh_project=0, verbose=False)
    glb.export(path, file_type="glb")
    return "UV и текстура PBR"


def install_bundled_weights(spec, stage):
    """Make bundled auxiliary files visible to the Windows TRELLIS runtime."""
    for group in components_for(spec):
        if not has_bundled_weights(group):
            continue
        files = missing(ROOT, weight_files(group))
        if files:
            stage("Подготовка встроенной модели · " + ("DINOv3" if group == "dino" else "RMBG-2.0"))
        for record in files:
            relative = Path(record["path"])
            source = BUNDLED_MODELS / relative.relative_to("trellis/src/MODELS")
            target = ROOT / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.with_name(target.name + ".bundled.part")
            temporary.unlink(missing_ok=True)
            try:
                os.link(source, temporary)
            except OSError:
                shutil.copyfile(source, temporary)
            temporary.replace(target)


def run(job_id):
    with gpu_lock() as free:
        if not free:
            return
        with database() as db:
            row = db.execute("SELECT id,spec FROM jobs WHERE status='waiting' ORDER BY id LIMIT 1").fetchone()
            if not row or row["id"] != job_id:
                return
            db.execute("UPDATE jobs SET status='running',note='Подготовка' WHERE id=?", (job_id,))
        start = time.monotonic()
        stop = threading.Event()
        device_peak = [0]
        exporter = None
        def watch():
            import ctypes as ct
            try:
                nvml = ct.WinDLL("nvml.dll")
                device = ct.c_void_p()
                memory = (ct.c_ulonglong * 3)()
                if nvml.nvmlInit_v2() or nvml.nvmlDeviceGetHandleByIndex_v2(0,ct.byref(device)):
                    nvml = None
            except OSError:
                nvml = None
            while not stop.wait(0.35):
                if nvml and not nvml.nvmlDeviceGetMemoryInfo(device,ct.byref(memory)):
                    device_peak[0] = max(device_peak[0],memory[2]/1048576)
                with database() as db:
                    status = db.execute("SELECT status FROM jobs WHERE id=?", (job_id,)).fetchone()[0]
                if status == "cancelling":
                    if exporter is not None and exporter.poll() is None:
                        exporter.terminate()
                    update(job_id, "cancelled", "Отменено", time.monotonic()-start)
                    os._exit(2)
        threading.Thread(target=watch, daemon=True).start()
        def stage(message):
            print(message, flush=True)
            with database() as db:
                db.execute("UPDATE jobs SET note=? WHERE id=?", (message, job_id))
        try:
            s = json.loads(row["spec"])
            src = ROOT / s["engine"] / "src"
            os.chdir(src)
            sys.path.insert(0, str(src))
            os.environ.update(HF_MODULES_CACHE=str(ROOT/"cache"/"hfmodules"), HY3DGEN_MODELS=str(ROOT/"models"), HF_HUB_CACHE=str(ROOT/"cache"/"hub"),
                              U2NET_HOME=str(ROOT/"models"/"rembg"), TORCH_HOME=str(ROOT/"cache"/"torch"),
                              NUMBA_CACHE_DIR=str(ROOT/"cache"/"numba"))
            if missing_components(ROOT, components_for(s)):
                raise RuntimeError("Отсутствуют компоненты. Нажмите «Скачать компоненты» в Blender")
            import torch
            if not torch.cuda.is_available():
                raise RuntimeError("PyTorch не видит CUDA в окружении движка")
            torch.cuda.reset_peak_memory_stats()
            stage("Подготовка изображений")
            folder = jobdir(job_id)
            folder.mkdir(parents=True, exist_ok=True)
            path = folder / "building.glb"
            note = {"hunyuan": hunyuan, "trellis": trellis}[s["engine"]](s, images_for(s), path, stage)
            with path.open("rb") as f:
                if f.read(4) != b"glTF":
                    raise ValueError("Движок вернул повреждённый GLB")
            gc.collect()
            torch.cuda.empty_cache()
            stage("Экспорт FBX и миниатюры")
            staging = folder / "exporting"
            blender = os.environ["PHOTO3D_BLENDER"]
            script = Path(__file__).resolve().with_name("export_result.py")
            exporter = subprocess.Popen([
                blender, "-b", "--factory-startup", "--offline-mode",
                "--python-exit-code", "1", "--python", str(script),
                "--", str(path), str(staging),
            ])
            if exporter.wait() != 0:
                raise RuntimeError("Не удалось сохранить FBX и миниатюру. Подробности в run.log")
            textures = staging / "Textures"
            if textures.exists():
                textures.rename(folder / textures.name)
            (staging / "preview.png").replace(folder / "preview.png")
            (staging / "model.fbx").replace(folder / "model.fbx")
            staging.rmdir()
            path.unlink()
            stop.set()
            (folder/"metrics.json").write_text(json.dumps({"seconds":time.monotonic()-start,
                "peak_card_mib":device_peak[0],"peak_torch_mib":torch.cuda.max_memory_reserved()/1048576,
                "device":torch.cuda.get_device_name(),"settings":s},ensure_ascii=False,indent=2),encoding="utf-8")
            with database() as db:
                db.execute("""UPDATE jobs SET status=CASE WHEN status='cancelling' THEN 'cancelled' ELSE 'done' END,
                           note=?,elapsed=?,peak=? WHERE id=?""",
                           (note,time.monotonic()-start,torch.cuda.max_memory_reserved()/1048576,job_id))
        except Exception as exc:
            traceback.print_exc()
            update(job_id, "error", str(exc)[:450], time.monotonic()-start)
        finally:
            stop.set()

if __name__ == "__main__":
    run(int(sys.argv[1]))




