import contextlib
import json
import msvcrt
import os
import shutil
import sqlite3
import time
from pathlib import Path

def extended_path(path):
    """Return an absolute path that Windows can use without its legacy length limit."""
    absolute = os.path.abspath(path)
    if absolute.startswith("\\\\?\\"):
        return Path(absolute)
    if absolute.startswith("\\\\"):
        return Path("\\\\?\\UNC\\" + absolute[2:])
    return Path("\\\\?\\" + absolute)


def runtime_root():
    if os.environ.get("PHOTO3D_HOME"):
        return Path(os.environ["PHOTO3D_HOME"])
    location = Path(__file__).with_name("runtime.json")
    if location.exists():
        return Path(json.loads(location.read_text(encoding="utf-8"))["runtime"])
    legacy = Path(os.getenv("LOCALAPPDATA", Path.home())) / "PhotoTo3D" / "runtime"
    if __package__ and __package__.startswith("bl_ext."):
        import bpy
        custom_profile = any(os.getenv(key) for key in (
            "BLENDER_USER_RESOURCES", "BLENDER_USER_CONFIG", "BLENDER_USER_EXTENSIONS",
        ))
        if (not custom_profile and not Path(__file__).with_name("PUBLIC_BUILD").exists()
                and (legacy / "queue.sqlite").is_file()):
            return legacy
        return Path(bpy.utils.extension_path_user(__package__, path="runtime"))
    return legacy

ROOT = runtime_root()
DATA = Path(os.environ.get("PHOTO3D_QUEUE_DIR", str(ROOT)))
NAMES = {"hunyuan": "Hunyuan3D 2.0", "trellis": "TRELLIS.2"}
FINISHED = ("done", "error", "cancelled", "interrupted")

@contextlib.contextmanager
def database():
    DATA.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DATA / "queue.sqlite", timeout=3)
    conn.row_factory = sqlite3.Row
    try:
        with conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS jobs
                (id INTEGER PRIMARY KEY, spec TEXT NOT NULL, status TEXT NOT NULL,
                 note TEXT DEFAULT '', elapsed REAL DEFAULT 0, peak REAL DEFAULT 0)""")
            yield conn
    finally:
        conn.close()

@contextlib.contextmanager
def gpu_lock():
    ROOT.mkdir(parents=True, exist_ok=True)
    with (ROOT / "gpu.lock").open("a+b") as lock:
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            yield False
            return
        try:
            yield True
        finally:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)

def enqueue(specs):
    with database() as db:
        db.executemany("INSERT INTO jobs(spec,status) VALUES (?, 'waiting')",
                       [(json.dumps(s, ensure_ascii=False),) for s in specs])

def next_job():
    with gpu_lock() as free:
        if not free:
            return
        with database() as db:
            db.execute("""UPDATE jobs SET status='cancelled',note='Движок удалён'
                WHERE status='waiting' AND json_extract(spec,'$.engine') NOT IN ('trellis','hunyuan')""")
            db.execute("UPDATE jobs SET status='interrupted' WHERE status IN ('running','cancelling')")
            return db.execute("SELECT * FROM jobs WHERE status='waiting' ORDER BY id LIMIT 1").fetchone()

def jobdir(job_id):
    return DATA / "results" / str(int(job_id))


def delete_job(job_id):
    """Remove a finished job's own result directory and queue entry."""
    folder = jobdir(job_id)
    results = DATA.resolve() / "results"
    with database() as db:
        db.execute("BEGIN IMMEDIATE")
        row = db.execute("SELECT status FROM jobs WHERE id=?", (job_id,)).fetchone()
        if not row or row["status"] not in FINISHED:
            return False
        if folder.resolve() != results / folder.name or folder.is_symlink():
            raise ValueError("Папка задания находится вне каталога результатов")
        if folder.exists():
            shutil.rmtree(folder)
        db.execute("DELETE FROM jobs WHERE id=?", (job_id,))
    return True

def python_for(engine):
    return ROOT / engine / "venv" / "Scripts" / "python.exe"

def update(job_id, status, note="", elapsed=0, peak=0):
    with database() as db:
        db.execute("UPDATE jobs SET status=?,note=?,elapsed=?,peak=? WHERE id=?",
                   (status, note, elapsed, peak, job_id))


