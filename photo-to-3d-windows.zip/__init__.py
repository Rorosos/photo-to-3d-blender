import json
import os
import random
import subprocess
import traceback
from pathlib import Path

import bpy
import bpy.utils.previews
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty,
                       IntProperty, PointerProperty, StringProperty)
from .component_catalog import COMPONENTS, INSTALL_MODELS, components_for, installation_spec, missing_components
from .i18n import BRAND, LANGUAGES, language, preferences, translate as tr
from .state import DATA, ROOT, NAMES, FINISHED, database, delete_job, enqueue, jobdir, next_job, python_for, update

WORKER = Path(__file__).with_name("worker.py")
INSTALLER = Path(__file__).with_name("component_install.py")
ONLINE_HELP = "Разрешите доступ в Интернет в настройках Blender → Система → Сеть"
STATUS = {"waiting":"В очереди", "running":"В работе", "cancelling":"Отмена…",
          "cancelled":"Отменено", "interrupted":"Прервано", "done":"Готово", "error":"Ошибка"}
process = None
active_id = None
preview = None
snapshot = []
refresh_key = None

def tick():
    global process, active_id, snapshot, refresh_key
    try:
        if process is None or process.poll() is not None:
            if process is not None and process.returncode not in (0,2):
                with database() as db:
                    db.execute("""UPDATE jobs SET status='error',note=? WHERE id=? AND status IN ('waiting','running')""",
                               (f"Процесс завершился с кодом {process.returncode}. Подробности в run.log",active_id))
            process = None
            row = next_job()
            if row:
                job_id = row["id"]
                active_id = job_id
                spec = json.loads(row["spec"])
                engine = spec["engine"]
                folder = jobdir(job_id)
                folder.mkdir(parents=True, exist_ok=True)
                try:
                    absent = missing_components(ROOT, components_for(spec))
                    args = [str(python_for(engine)), "-u", str(WORKER), str(job_id)]
                    if spec.get("action") == "setup" or absent:
                        args = [bpy.app.binary_path, "-b", "--factory-startup", "--offline-mode",
                                "--python-exit-code", "1", "--python", str(INSTALLER), "--", str(job_id)]
                    env = {**os.environ, "PYTHONUTF8":"1", "PYTHONIOENCODING":"utf-8",
                           "PHOTO3D_BLENDER":bpy.app.binary_path, "PHOTO3D_HOME":str(ROOT),
                           "PHOTO3D_QUEUE_DIR":str(DATA)}
                    if absent and not bpy.app.online_access:
                        update(job_id, "error", ONLINE_HELP)
                    else:
                        with (folder/"run.log").open("ab") as log:
                            process = subprocess.Popen(args,
                                stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW,
                                env=env)
                except OSError as exc:
                    update(job_id,"error",str(exc))
        with database() as db:
            snapshot = [dict(r) for r in db.execute("""SELECT * FROM jobs ORDER BY
                CASE WHEN status IN ('running','cancelling') THEN 0 WHEN status='waiting' THEN 1 ELSE 2 END,
                CASE WHEN status='waiting' THEN id ELSE -id END""")]
        key = [(r["id"], r["status"], r["note"]) for r in snapshot]
        if key != refresh_key:
            refresh_key = key
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == "VIEW_3D":
                        area.tag_redraw()
    except Exception:
        traceback.print_exc()
    return 0.8

class PhotoInput(bpy.types.PropertyGroup):
    path: StringProperty(subtype="FILE_PATH")


class PHOTO_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    language: EnumProperty(
        name="Language",
        items=[("auto", "Blender", ""), *((code, name, "") for code, name in LANGUAGES.items())],
        default="auto",
    )

    def draw(self, context):
        self.layout.prop(self, "language", text=tr("Язык"))


class PhotoSettings(bpy.types.PropertyGroup):
    tab: EnumProperty(name="Раздел",items=[("generate","Генерация",""),("examples","Пример",""),
                                           ("components","Компоненты","")])
    mode: EnumProperty(name="Режим",items=[("single","По модели на фото",""),("multi","Несколько ракурсов","")])
    engine: EnumProperty(name="Движок",items=[("hunyuan",NAMES["hunyuan"],"Один или несколько ракурсов",1),
                                             ("trellis",NAMES["trellis"],"Модель с PBR-материалом",2)],
                         default="trellis")
    inputs: CollectionProperty(type=PhotoInput)
    front: StringProperty(name="Спереди",subtype="FILE_PATH")
    left: StringProperty(name="Слева",subtype="FILE_PATH")
    back: StringProperty(name="Сзади",subtype="FILE_PATH")
    background: BoolProperty(name="Удалять фон",default=True)
    texture: EnumProperty(name="Текстура",items=[(str(n),f"{n} px","") for n in (512,1024,2048)],default="1024")
    detail: EnumProperty(name="Детализация",items=[(str(n),str(n)+"³","") for n in (128,192,256,384)],default="192")
    target: IntProperty(name="Цель, вершин",default=20000,min=500,max=250000)
    paint: BoolProperty(name="Попробовать Hunyuan Paint",default=False)
    seed: IntProperty(name="Seed (−1 = случайный)",default=-1,min=-1)
    variants: IntProperty(name="Вариантов",default=1,min=1,max=32)
    steps: IntProperty(name="Шагов на этап",default=12,min=4,max=30)
    ratio: FloatProperty(name="Оставить треугольников",subtype="PERCENTAGE",min=1,max=99,default=50)
    page: IntProperty(name="Страница очереди",default=1,min=1)

def preview_icon(path):
    if not path:
        return 0
    path = bpy.path.abspath(path)
    if not os.path.isfile(path):
        return 0
    try:
        if path not in preview:
            preview.load(path, path, "IMAGE")
        return preview[path].icon_id
    except (KeyError, RuntimeError):
        return 0


def thumb(layout, path, scale=2.4):
    icon = preview_icon(path)
    if icon:
        layout.template_icon(icon_value=icon,scale=scale)

class PHOTO_OT_files(bpy.types.Operator):
    bl_idname="photo3d.files"
    bl_label="Выбрать фотографию"
    bl_description="Добавить JPG или PNG. Файлы можно перетащить на кнопку или на превью в панели"
    directory: StringProperty(subtype="DIR_PATH",options={"SKIP_SAVE"})
    files: CollectionProperty(type=bpy.types.OperatorFileListElement,options={"SKIP_SAVE"})
    replace_index: IntProperty(default=-1,options={"HIDDEN","SKIP_SAVE"})
    filter_glob: StringProperty(default="*.png;*.jpg;*.jpeg",options={"HIDDEN"})
    def invoke(self,context,event):
        if self.files:
            return self.execute(context)
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    @classmethod
    def description(cls, context, properties):
        if properties.replace_index >= 0:
            return tr("Для замены выберите один снимок")
        return tr("Выбрать фотографию")

    def execute(self,context):
        inputs=context.scene.photo3d.inputs
        paths = [Path(self.directory) / item.name for item in self.files]
        paths = [str(path) for path in paths if path.is_file()
                 and path.suffix.lower() in (".png", ".jpg", ".jpeg")]
        if not paths:
            self.report({"WARNING"}, tr("Выберите фотографию JPG или PNG"))
            return {"CANCELLED"}
        if 0 <= self.replace_index < len(inputs):
            if len(paths) != 1:
                self.report({"WARNING"}, tr("Для замены выберите один снимок"))
                return {"CANCELLED"}
            inputs[self.replace_index].path = paths[0]
            return {"FINISHED"}
        for path in paths:
            if not any(item.path==path for item in inputs):
                inputs.add().path=path
        return {"FINISHED"}


class PHOTO_FH_images(bpy.types.FileHandler):
    bl_idname = "PHOTO_FH_images"
    bl_label = BRAND
    bl_import_operator = "photo3d.files"
    bl_file_extensions = ".png;.jpg;.jpeg"

    @classmethod
    def poll_drop(cls, context):
        return bool(context.area and context.area.type == "VIEW_3D"
                    and context.region and context.region.type == "UI"
                    and context.region.active_panel_category == BRAND
                    and context.scene.photo3d.tab == "generate"
                    and context.scene.photo3d.mode == "single")


class PHOTO_OT_remove(bpy.types.Operator):
    bl_idname="photo3d.remove"
    bl_label="Убрать снимок"
    bl_description="Убрать фотографию из списка загрузки"
    index: IntProperty()
    def execute(self,context):
        context.scene.photo3d.inputs.remove(self.index)
        return {"FINISHED"}

def selected_profile(settings):
    multi = settings.mode == "multi"
    return dict(engine="hunyuan" if multi else (settings.engine or "trellis"),
                images=("front", "left") if multi else ("front",),
                paint=settings.paint, background=settings.background)


class PHOTO_OT_component(bpy.types.Operator):
    bl_idname = "photo3d.component"
    bl_label = "Скачать компонент"
    bl_description = "Скачать и установить модель, её движок и необходимые компоненты"
    component: EnumProperty(items=[("profile", "Текущий профиль", ""),
                                   *((key, name, "") for key, name in COMPONENTS.items())],
                            default="profile", options={"SKIP_SAVE"})

    @classmethod
    def description(cls, context, properties):
        return tr("Скачать модель и движок")

    def execute(self, context):
        if not bpy.app.online_access:
            self.report({"WARNING"}, tr(ONLINE_HELP))
            return {"CANCELLED"}
        spec = installation_spec(self.component, selected_profile(context.scene.photo3d))
        absent = missing_components(ROOT, components_for(spec))
        if not absent:
            self.report({"INFO"}, tr("Компоненты уже установлены"))
            return {"CANCELLED"}
        with database() as db:
            db.execute("BEGIN IMMEDIATE")
            pending = set()
            for job in db.execute("SELECT spec FROM jobs WHERE status IN ('waiting','running')"):
                active_spec = json.loads(job["spec"])
                if active_spec.get("action") == "setup":
                    pending.update(components_for(active_spec))
            if pending.issuperset(absent):
                self.report({"INFO"}, tr("Загрузка уже в очереди"))
                return {"CANCELLED"}
            db.execute("INSERT INTO jobs(spec,status) VALUES (?,'waiting')", (json.dumps(spec),))
        self.report({"INFO"}, tr("Загрузка добавлена в очередь"))
        return {"FINISHED"}


class PHOTO_OT_enqueue(bpy.types.Operator):
    bl_idname="photo3d.enqueue"
    bl_label="В очередь"
    bl_description="Поставить генерацию с установленными компонентами в очередь"

    def specs(self,context):
        p=context.scene.photo3d
        multi=p.mode=="multi"
        engine="hunyuan" if multi else (p.engine or "trellis")
        groups=[{k:bpy.path.abspath(getattr(p,k)) for k in ("front","left","back") if getattr(p,k)}] if multi else [
            {"front":bpy.path.abspath(i.path)} for i in p.inputs]
        if not groups or (multi and ("front" not in groups[0] or len(groups[0])<2)):
            self.report({"ERROR"},tr("Выберите снимки. Для ракурсов нужны передний и ещё один вид"))
            return []
        for views in groups:
            for path in views.values():
                if not Path(path).is_file() or Path(path).suffix.lower() not in (".png",".jpg",".jpeg"):
                    self.report({"ERROR"}, f"{tr('Проверьте файл')} · {path}")
                    return []
        specs=[]
        for views in groups:
            seed=p.seed if p.seed>=0 else random.randrange(2**31)
            for i in range(p.variants):
                specs.append(dict(engine=engine,images=views,background=p.background,texture=int(p.texture),
                     detail=int(p.detail),target=p.target,paint=p.paint,seed=seed+i,steps=p.steps))
        return specs

    def execute(self,context):
        specs = self.specs(context)
        if not specs:
            return {"CANCELLED"}
        if missing_components(ROOT, components_for(specs[0])):
            self.report({"WARNING"}, tr("Скачать модель и движок"))
            return {"CANCELLED"}
        enqueue(specs)
        self.report({"INFO"},f"{tr('Добавлено заданий')} · {len(specs)}")
        return {"FINISHED"}

class PHOTO_OT_job(bpy.types.Operator):
    bl_idname="photo3d.job"
    bl_label="Действие с заданием"
    job: IntProperty()
    action: StringProperty()

    @classmethod
    def description(cls, context, properties):
        if language() != "ru":
            return tr({
                "cancel": "Отменить",
                "retry": "Повторить",
                "import": "Добавить в сцену",
                "folder": "Папка задания",
                "delete": "Файлы задания будут удалены с диска",
            }.get(properties.action, "Очередь"))
        return {
            "cancel": "Остановить генерацию или снять задание с очереди",
            "retry": "Запустить новое задание с теми же настройками",
            "import": "Импортировать FBX и загрузить текстуры в текущую сцену",
            "folder": "Открыть папку с моделью, текстурами и журналом",
            "delete": "Навсегда удалить задание и его папку с диска",
        }.get(properties.action, cls.bl_label)

    def invoke(self, context, event):
        if self.action == "delete":
            return context.window_manager.invoke_confirm(
                self, event, title=f"{tr('Удалить задание?')} #{self.job}",
                message=tr("Файлы задания будут удалены с диска"),
                confirm_text=tr("Удалить"), icon="WARNING",
            )
        return self.execute(context)

    def execute(self,context):
        if self.action == "delete":
            try:
                if not delete_job(self.job):
                    return {"CANCELLED"}
            except (OSError, ValueError) as exc:
                self.report({"ERROR"}, str(exc))
                return {"CANCELLED"}
            key = str(jobdir(self.job) / "preview.png")
            if key in preview:
                del preview[key]
            return {"FINISHED"}
        with database() as db:
            row=db.execute("SELECT * FROM jobs WHERE id=?",(self.job,)).fetchone()
            if not row:
                return {"CANCELLED"}
            if self.action=="cancel":
                db.execute("""UPDATE jobs SET status=CASE status WHEN 'waiting' THEN 'cancelled' ELSE 'cancelling' END
                              WHERE id=? AND status IN ('running','waiting')""",(self.job,))
            elif self.action=="retry":
                spec = json.loads(row["spec"])
                if spec["engine"] in NAMES and row["status"] in FINISHED:
                    if missing_components(ROOT, components_for(spec)):
                        if not bpy.app.online_access:
                            self.report({"WARNING"}, tr(ONLINE_HELP))
                            return {"CANCELLED"}
                        spec["allow_setup"] = True
                    db.execute("INSERT INTO jobs(spec,status) VALUES (?,'waiting')",(json.dumps(spec),))
            elif self.action=="import":
                folder = jobdir(self.job)
                result = folder / "model.fbx"
                if not result.is_file():
                    result = folder / "model.glb"
                if not result.is_file():
                    self.report({"ERROR"},tr("Файл результата отсутствует"))
                    return {"CANCELLED"}
                if import_model(result) != {"FINISHED"}:
                    return {"CANCELLED"}
                if json.loads(row["spec"])["engine"]=="trellis":
                    (ROOT/"trellis"/"verified").write_text(str(self.job))
            elif self.action=="folder":
                folder=jobdir(self.job)
                if folder.exists():
                    bpy.ops.wm.path_open(filepath=str(folder))
        return {"FINISHED"}

class PHOTO_OT_simplify(bpy.types.Operator):
    bl_idname="photo3d.simplify"
    bl_label="Упростить копию"
    bl_description="Сделать копию выбранной сетки с меньшим числом треугольников"
    bl_options={"REGISTER","UNDO"}
    def execute(self,context):
        obj=context.active_object
        if not obj or obj.type!="MESH":
            return {"CANCELLED"}
        copy=obj.copy()
        copy.data=obj.data.copy()
        copy.name=obj.name+" · упрощённая"
        context.collection.objects.link(copy)
        mod=copy.modifiers.new("Упрощение","DECIMATE")
        mod.ratio=context.scene.photo3d.ratio/100
        bpy.ops.object.select_all(action="DESELECT")
        copy.select_set(True)
        context.view_layer.objects.active=copy
        bpy.ops.object.modifier_apply(modifier=mod.name)
        return {"FINISHED"}

EXAMPLES=Path(__file__).with_name("examples")
DESCRIPTIONS={
    "trellis": ("Создаёт материалы", "Один ракурс"),
    "hunyuan": ("Поддерживает ракурсы", "Paint расходует много VRAM"),
}

def describe(layout,engine):
    plus, minus=DESCRIPTIONS[engine]
    layout.label(text="+ "+tr(plus))
    layout.label(text="− "+tr(minus))

def example_path(engine):
    return EXAMPLES / engine / "model.fbx"


def import_model(path):
    if path.suffix == ".glb":
        return bpy.ops.import_scene.gltf(filepath=str(path))
    previous = set(bpy.data.images)
    status = bpy.ops.import_scene.fbx(filepath=str(path), use_image_search=False)
    for image in set(bpy.data.images) - previous:
        if image.has_data and not image.packed_file:
            image.pack()
    return status

def examples_panel(layout):
    layout.label(text=tr("Один снимок · один предмет"))
    thumb(layout,str(EXAMPLES/"source.png"),4.0)
    for engine in ("trellis","hunyuan"):
        if not example_path(engine).is_file():
            continue
        box=layout.box()
        box.label(text=NAMES[engine])
        describe(box,engine)
        thumb(box,str(EXAMPLES/engine/"preview.png"),6.0)
        box.operator("photo3d.example",text=tr("Вставить в сцену"),icon="IMPORT").engine=engine


def components_panel(layout):
    if not bpy.app.online_access:
        layout.label(text=tr("Доступ в Интернет выключен"), icon="INFO")
    for key, name in INSTALL_MODELS.items():
        box = layout.box()
        ready = not missing_components(ROOT, components_for(installation_spec(key)))
        box.label(text=tr(name), icon="CHECKMARK" if ready else "PACKAGE")
        if not ready:
            box.operator("photo3d.component", text=tr("Скачать"), icon="IMPORT").component = key


class PHOTO_OT_example(bpy.types.Operator):
    bl_idname="photo3d.example"
    bl_label="Вставить пример"
    bl_description="Импортировать этот пример с текстурами к 3D-курсору"
    bl_options={"REGISTER","UNDO"}
    engine: EnumProperty(items=[(k,v,"") for k,v in NAMES.items()])
    def execute(self,context):
        path=example_path(self.engine)
        if not path.is_file():
            self.report({"ERROR"},tr("Файл примера отсутствует"))
            return {"CANCELLED"}
        before=set(bpy.data.objects)
        if import_model(path)!={"FINISHED"}:
            return {"CANCELLED"}
        added=set(bpy.data.objects)-before
        for obj in added:
            if obj.parent not in added:
                obj.location += context.scene.cursor.location
        meshes=[o for o in added if o.type=="MESH"]
        if meshes:
            meshes[0].name=NAMES[self.engine]+" · Бургер"
            context.view_layer.objects.active=meshes[0]
        if context.area and context.area.type=="VIEW_3D":
            context.space_data.shading.type="MATERIAL"
            region=next((r for r in context.area.regions if r.type=="WINDOW"),None)
            if region:
                with context.temp_override(region=region):
                    bpy.ops.view3d.view_selected(use_all_regions=False)
        return {"FINISHED"}

class PHOTO_PT_panel(bpy.types.Panel):
    bl_label=BRAND
    bl_idname="PHOTO_PT_panel"
    bl_space_type="VIEW_3D"
    bl_region_type="UI"
    bl_category=BRAND
    def draw(self,context):
        p=context.scene.photo3d
        col=self.layout.column()
        if prefs := preferences():
            col.prop(prefs, "language", text=tr("Язык"))
        tabs = col.row(align=True)
        for key, text in (("generate", "Генерация"), ("examples", "Пример"), ("components", "Компоненты")):
            tabs.prop_enum(p, "tab", key, text=tr(text))
        if p.tab=="examples":
            examples_panel(col)
            return
        if p.tab == "components":
            components_panel(col)
            self.draw_queue(col, p)
            return
        mode = col.row(align=True)
        mode.prop_enum(p, "mode", "single", text=tr("По модели на фото"))
        mode.prop_enum(p, "mode", "multi", text=tr("Несколько ракурсов"))
        spec = selected_profile(p)
        engine = spec["engine"]
        if p.mode=="single":
            col.prop(p,"engine",text=tr("Движок"))
            describe(col,engine)
            col.operator("photo3d.files",text=tr("Выбрать фотографию"),icon="FILE_FOLDER")
            for idx,item in enumerate(p.inputs):
                row=col.row(align=True)
                icon = preview_icon(item.path)
                slot = row.operator("photo3d.files", text=Path(item.path).name,
                                    icon_value=icon, icon="IMAGE_DATA" if not icon else "NONE")
                slot.replace_index = idx
                row.operator("photo3d.remove",text="",icon="X").index=idx
        else:
            col.label(text="Hunyuan3D-2mv")
            describe(col,"hunyuan")
            for k, label in (("front", "Спереди"), ("left", "Слева"), ("back", "Сзади")):
                row=col.row()
                thumb(row,getattr(p,k))
                row.prop(p,k,text=tr(label))
        col.prop(p,"background",text=tr("Удалять фон"))
        if engine!="hunyuan" or p.paint:
            col.prop(p,"texture",text=tr("Текстура"))
        if engine=="hunyuan":
            col.prop(p,"detail",text=tr("Детализация"))
        if engine=="hunyuan":
            col.prop(p,"paint",text=tr("Попробовать Hunyuan Paint"))
        col.prop(p,"seed",text=tr("Seed (−1 = случайный)"))
        col.prop(p,"variants",text=tr("Вариантов"))
        if engine=="trellis":
            col.prop(p,"steps",text=tr("Шагов на этап"))
        col.prop(p,"target",text=tr("Цель, вершин"))
        absent = missing_components(ROOT, components_for(spec))
        if absent:
            col.operator("photo3d.component",text=tr("Скачать модель и движок"),icon="IMPORT").component="profile"
        else:
            col.operator("photo3d.enqueue",text=tr("В очередь"),icon="ADD")
        self.draw_queue(col, p)
        obj=context.active_object
        if obj and obj.type=="MESH" and context.mode=="OBJECT":
            box=col.box()
            obj.data.calc_loop_triangles()
            box.label(text=f"{obj.name} · {len(obj.data.loop_triangles):,} треуг.")
            box.prop(p,"ratio",text=tr("Оставить треугольников"))
            box.operator("photo3d.simplify",text=tr("Упростить копию"))

    def draw_queue(self, col, p):
        col.separator()
        col.label(text=f"{tr('Очередь')} · {len(snapshot)}")
        if len(snapshot)>6 or p.page>1:
            col.prop(p,"page",text=tr("Страница очереди"))
        for r in snapshot[(p.page-1)*6:p.page*6]:
            s=json.loads(r["spec"])
            box=col.box()
            setup = s.get("action") == "setup"
            if setup:
                box.label(text=f"#{r['id']}  {tr('Компоненты')} · {tr(STATUS[r['status']])}")
                components = components_for(s)
                box.label(text=tr(COMPONENTS[components[0]]) if len(components) == 1 else NAMES[s["engine"]])
            else:
                box.label(text=f"#{r['id']}  {Path(s['images']['front']).stem} · {tr(STATUS[r['status']])}")
                box.label(text=NAMES.get(s["engine"],s["engine"])+(" · "+tr("Ракурсы") if len(s["images"])>1 else ""))
            if r["status"] == "done" and not setup:
                thumb(box, str(jobdir(r["id"]) / "preview.png"), 3.0)
            if r["note"]:
                note=tr(r["note"])
                if language() != "ru" and note == r["note"] and any("а" <= c.lower() <= "я" for c in note):
                    note = tr("Откройте журнал задания")
                box.label(text=note[:80])
            if r["elapsed"] and setup:
                box.label(text=f"{r['elapsed']:.1f} с")
            elif r["elapsed"]:
                box.label(text=f"{r['elapsed']:.1f} с · PyTorch {r['peak']:.0f} МиБ")
            row=box.row(align=True)
            def button(action,label,icon):
                op=row.operator("photo3d.job",text=tr(label),icon=icon)
                op.job=r["id"]
                op.action=action
            if r["status"] in ("waiting","running"):
                button("cancel","Отменить","X")
            elif r["status"]!="cancelling":
                if r["status"]=="done" and not setup:
                    button("import","Добавить в сцену","IMPORT")
                if s["engine"] in NAMES:
                    button("retry","","FILE_REFRESH")
                button("folder","","FILE_FOLDER")
                button("delete","","TRASH")

classes=(PHOTO_Preferences,PhotoInput,PhotoSettings,PHOTO_OT_files,PHOTO_FH_images,PHOTO_OT_remove,
         PHOTO_OT_enqueue,PHOTO_OT_job,PHOTO_OT_component,
         PHOTO_OT_simplify,PHOTO_OT_example,PHOTO_PT_panel)

def register():
    global preview
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.photo3d=PointerProperty(type=PhotoSettings)
    preview=bpy.utils.previews.new()
    bpy.app.timers.register(tick,first_interval=0.5,persistent=True)

def unregister():
    if bpy.app.timers.is_registered(tick):
        bpy.app.timers.unregister(tick)
    bpy.utils.previews.remove(preview)
    del bpy.types.Scene.photo3d
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


