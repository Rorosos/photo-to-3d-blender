"""Download the files needed by the selected generation profile."""

import json
import os
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote

if __package__:
    from .download_file import fetch
else:
    from download_file import fetch

CATALOG = json.loads(Path(__file__).with_name("weights.json").read_text(encoding="utf-8"))


def needed(spec):
    if spec["engine"] == "trellis":
        groups = {"trellis"}
    else:
        groups = {"mv" if len(spec["images"]) > 1 else "mini"}
        if spec["paint"]:
            groups.add("paint")
    return [item for item in CATALOG if item["group"] in groups]


def missing(root, files):
    return [item for item in files
            if not (path := root / item["path"]).is_file()
            or path.stat().st_size not in (item["size"], item.get("legacy_size"))]


def download(root, spec, stage):
    download_files(root, needed(spec), stage)


def hub_token():
    if token := os.getenv("HF_TOKEN"):
        return token
    home = Path(os.getenv("HF_HOME", Path.home() / ".cache" / "huggingface"))
    path = Path(os.getenv("HF_TOKEN_PATH", home / "token"))
    try:
        return path.read_text(encoding="utf-8").strip()
    except OSError:
        return None


def download_files(root, records, stage):
    files = missing(root, records)
    if files and os.getenv("HF_HUB_OFFLINE", "").lower() in {"1", "true", "on", "yes"}:
        raise RuntimeError("Веса отсутствуют. Для докачки нужен Интернет")
    token = hub_token()
    for number, item in enumerate(files, start=1):
        stage(f"Загрузка весов {number}/{len(files)} · {Path(item['file']).name}")
        url = f"https://huggingface.co/{item['repo']}/resolve/{item['revision']}/{quote(item['file'])}"
        try:
            checksum = item.get("sha256") or f"git:{item['git_blob']}"
            fetch(url, root / item["path"], checksum, item["size"], token)
        except HTTPError as exc:
            if exc.code not in {401, 403}:
                raise
            raise RuntimeError(
                f"Hugging Face ограничил доступ к {item['repo']}. "
                "Примите условия модели и укажите токен чтения во вкладке «Компоненты»."
            ) from None
