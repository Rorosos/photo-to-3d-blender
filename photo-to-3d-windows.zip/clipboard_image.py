"""Read a copied Windows image and keep a PNG for Blender and the queue."""

import ctypes
from ctypes import wintypes
import hashlib
from pathlib import Path
import struct
from tempfile import TemporaryDirectory

import bpy


CF_DIB = 8
CF_DIBV5 = 17
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
MAX_PIXELS = 64 * 1024 * 1024
MAX_CLIPBOARD_BYTES = 4 * MAX_PIXELS + 1024 * 1024

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
user32.OpenClipboard.argtypes = (wintypes.HWND,)
user32.CloseClipboard.argtypes = ()
user32.RegisterClipboardFormatW.argtypes = (wintypes.LPCWSTR,)
user32.RegisterClipboardFormatW.restype = wintypes.UINT
user32.GetClipboardData.argtypes = (wintypes.UINT,)
user32.GetClipboardData.restype = wintypes.HANDLE
kernel32.GlobalSize.argtypes = (wintypes.HGLOBAL,)
kernel32.GlobalSize.restype = ctypes.c_size_t
kernel32.GlobalLock.argtypes = (wintypes.HGLOBAL,)
kernel32.GlobalLock.restype = ctypes.c_void_p
kernel32.GlobalUnlock.argtypes = (wintypes.HGLOBAL,)


def clipboard_bytes(format_id):
    handle = user32.GetClipboardData(format_id)
    if not handle:
        return None
    size = kernel32.GlobalSize(handle)
    if not 0 < size <= MAX_CLIPBOARD_BYTES:
        raise ValueError("Unsupported clipboard image size")
    address = kernel32.GlobalLock(handle)
    if not address:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(address, size)
    finally:
        kernel32.GlobalUnlock(handle)


def check_dimensions(width, height):
    if width <= 0 or height <= 0 or width * height > MAX_PIXELS:
        raise ValueError("Unsupported image dimensions")


def png_image_bytes(data):
    if len(data) < 33 or not data.startswith(PNG_SIGNATURE + b"\x00\x00\x00\x0dIHDR"):
        raise ValueError("Invalid clipboard PNG header")
    check_dimensions(*struct.unpack_from(">II", data, 16))
    offset = len(PNG_SIGNATURE)
    while offset + 12 <= len(data):
        size, kind = struct.unpack_from(">I4s", data, offset)
        offset += size + 12
        if offset > len(data):
            break
        if kind == b"IEND" and size == 0:
            return data[:offset]
    raise ValueError("Incomplete clipboard PNG")


def dib_to_bmp(data):
    """Add the BMP file header that a packed Windows DIB does not contain."""
    if len(data) < 12:
        raise ValueError("Incomplete clipboard bitmap header")
    header_size, = struct.unpack_from("<I", data)
    if header_size == 12:
        width, height, planes, depth = struct.unpack_from("<4H", data, 4)
        palette_size, colors, masks, compression = 3, 0, 0, 0
    elif header_size in (40, 52, 56, 108, 124) and len(data) >= header_size:
        width, height, planes, depth, compression = struct.unpack_from("<iiHHI", data, 4)
        colors, = struct.unpack_from("<I", data, 32)
        palette_size = 4
        masks = {3: 12, 6: 16}.get(compression, 0) if header_size == 40 else 0
    else:
        raise ValueError("Unsupported clipboard bitmap header")
    check_dimensions(width, abs(height))
    if planes != 1 or depth not in (1, 4, 8, 16, 24, 32) or compression not in (0, 1, 2, 3, 6):
        raise ValueError("Unsupported clipboard bitmap format")
    if depth <= 8 and not colors:
        colors = 1 << depth
    pixel_start = header_size + masks + colors * palette_size
    if pixel_start >= len(data):
        raise ValueError("Incomplete clipboard bitmap")
    if compression in (0, 3, 6):
        row_stride = ((width * depth + 31) // 32) * 4
        if pixel_start + row_stride * abs(height) > len(data):
            raise ValueError("Incomplete clipboard pixels")
    return struct.pack("<2sIHHI", b"BM", 14 + len(data), 0, 0, 14 + pixel_start) + data


def read_image():
    """Copy image bytes out of the clipboard before Blender decodes them."""
    png_format = user32.RegisterClipboardFormatW("PNG")
    if not user32.OpenClipboard(None):
        raise ctypes.WinError(ctypes.get_last_error())
    invalid = None
    try:
        for format_id in (png_format, CF_DIBV5, CF_DIB):
            if not format_id:
                continue
            try:
                data = clipboard_bytes(format_id)
                if data is None:
                    continue
                if format_id == png_format:
                    return ".png", png_image_bytes(data)
                return ".bmp", dib_to_bmp(data)
            except ValueError as error:
                invalid = error
    finally:
        user32.CloseClipboard()
    if invalid:
        raise invalid
    return None


def save_png(folder, picture):
    extension, data = picture
    name = f"clipboard-{hashlib.sha256(data).hexdigest()[:16]}.png"
    target = Path(folder) / name
    if target.is_file():
        return target
    target.parent.mkdir(parents=True, exist_ok=True)
    # The queued job keeps the final path. Temporary inputs only live through decoding.
    with TemporaryDirectory(dir=target.parent) as temp:
        source = Path(temp) / ("image" + extension)
        source.write_bytes(data)
        image = bpy.data.images.load(str(source), check_existing=False)
        try:
            if not all(image.size):
                raise ValueError("Clipboard image could not be decoded")
            if extension != ".png":
                image.file_format = "PNG"
                source = source.with_suffix(".png")
                image.filepath_raw = str(source)
                image.save()
            source.replace(target)
        finally:
            bpy.data.images.remove(image)
    return target
