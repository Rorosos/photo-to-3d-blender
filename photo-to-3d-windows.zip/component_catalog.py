"""Component selection and local readiness shared by Blender and the installer."""

import json
from pathlib import Path

if __package__:
    from .model_weights import CATALOG, missing
else:
    from model_weights import CATALOG, missing

DATA = Path(__file__).with_name("components")
BUNDLED_MODELS = Path(__file__).with_name("MODELS")
SOURCES = json.loads((DATA / "sources.json").read_text(encoding="utf-8"))
AUXILIARY = json.loads((DATA / "aux_weights.json").read_text(encoding="utf-8"))

ENVIRONMENTS = {"trellis_env": "TRELLIS.2 · Python / PyTorch / CUDA",
                "hunyuan_env": "Hunyuan3D · Python / PyTorch / CUDA"}
WEIGHT_GROUPS = {"trellis": "TRELLIS.2 · основные веса",
                 "mini": "Hunyuan3D · одно фото",
                 "mv": "Hunyuan3D · несколько ракурсов",
                 "paint": "Hunyuan Paint · текстуры",
                 "dino": "DINOv3 · признаки для TRELLIS.2",
                 "birefnet": "BiRefNet · фон для TRELLIS.2",
                 "u2netp": "U²-Net · фон для Hunyuan3D"}
COMPONENTS = {**ENVIRONMENTS, **WEIGHT_GROUPS}
INSTALL_MODELS = {key: WEIGHT_GROUPS[key] for key in ("trellis", "mini", "mv", "paint")}
U2NET_PATH = "models/rembg/u2netp.onnx"


def weight_files(component):
    return [record for record in CATALOG + AUXILIARY if record["group"] == component]


def bundled_weights(component):
    if component != "dino":
        return []
    return [dict(record, path=Path(record["path"]).relative_to("trellis/src/MODELS"))
            for record in weight_files(component)]


def has_bundled_weights(component):
    files = bundled_weights(component)
    return bool(files) and not missing(BUNDLED_MODELS, files)


def environment_missing(root, engine):
    env = root / engine / "venv"
    packages = env / "Lib" / "site-packages"
    other = {
        "trellis": ("xformers/__init__.py", "cumesh/__init__.py", "o_voxel/postprocess.py",
                    "flex_gemm/__init__.py", "triton/__init__.py"),
        "hunyuan": ("diffusers/__init__.py", "nvdiffrast/torch/__init__.py",
                    "pymeshlab/__init__.py", "rembg/__init__.py", "onnxruntime/__init__.py"),
    }[engine]
    files = (
        env / "Scripts/python.exe", env / "pyvenv.cfg",
        root / engine / "src" / ("pipeline_worker.py" if engine == "trellis" else "hy3dgen/shapegen/__init__.py"),
        *(packages / part for part in (
            "torch/__init__.py", "torch/lib/torch_cuda.dll", "torch/lib/cudart64_12.dll",
            "torch/lib/cublas64_12.dll", "torch/lib/cudnn64_9.dll", "torchvision/__init__.py",
            "numpy/__init__.py", "PIL/__init__.py", "transformers/__init__.py", *other,
        )),
    )
    if not all(path.is_file() for path in files):
        return True
    try:
        cfg = (env / "pyvenv.cfg").read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        return True
    for line in cfg.splitlines():
        key, _, home = line.partition("=")
        if key.strip() == "home":
            return not (env / home.strip() / "python.exe").is_file()
    return True


def missing_components(root, components):
    result = {}
    for entry in dict.fromkeys(components):
        if entry in ENVIRONMENTS:
            if environment_missing(root, entry.removesuffix("_env")):
                result[entry] = None
        elif entry == "u2netp":
            path = root / U2NET_PATH
            expected = SOURCES["u2netp.onnx"]["size"]
            if not path.is_file() or path.stat().st_size != expected:
                result[entry] = expected
        else:
            if has_bundled_weights(entry):
                continue
            files = missing(root, weight_files(entry))
            if files:
                result[entry] = sum(file["size"] for file in files)
    return result


def components_for(spec):
    if spec.get("action") == "setup":
        components = ["birefnet" if key == "rmbg" else key for key in spec["components"]]
        # Repair installation jobs saved by earlier releases which could queue weights alone.
        if "trellis" in components:
            components = ["trellis_env", "dino", *components]
        if set(components).intersection(("mini", "mv", "paint")):
            components.insert(0, "hunyuan_env")
        return list(dict.fromkeys(components))
    if spec["engine"] == "trellis":
        return ["trellis_env", "dino", "trellis"] + (["birefnet"] if spec["background"] else [])
    return (["hunyuan_env", "mv" if len(spec["images"]) > 1 else "mini"]
            + (["paint"] if spec["paint"] else []) + (["u2netp"] if spec["background"] else []))


def installation_spec(component, profile=None):
    if component == "profile":
        engine = profile["engine"]
        components = components_for(profile)
    elif component == "trellis":
        engine = "trellis"
        components = components_for(dict(engine=engine, background=True))
    elif component in ("mini", "mv"):
        engine = "hunyuan"
        views = ("front", "left") if component == "mv" else ("front",)
        components = components_for(dict(engine=engine, images=views, paint=False, background=True))
    else:
        engine = "trellis" if component in ("trellis_env", "dino", "birefnet") else "hunyuan"
        components = components_for(dict(action="setup", components=[component]))
    return dict(action="setup", engine=engine, components=components)
