from pathlib import Path

def load(folder, dtype):
    import json
    import torch
    from accelerate import init_empty_weights
    from diffusers import AutoencoderKL, DDIMScheduler, UNet2DConditionModel
    from safetensors.torch import load_file
    from transformers import CLIPImageProcessor, CLIPTextModel, CLIPTokenizer
    from hy3dgen.texgen.hunyuanpaint.pipeline import HunyuanPaintPipeline
    from hy3dgen.texgen.hunyuanpaint.unet.modules import UNet2p5DConditionModel
    root = Path(folder)
    with init_empty_weights():
        config = json.loads((root/"unet"/"config.json").read_text())
        base = UNet2DConditionModel.from_config(config)
        unet = UNet2p5DConditionModel(base)
    state = load_file(str(root/"unet"/"diffusion_pytorch_model.safetensors"))
    # The FP16 archive also contains optional IP-Adapter weights. This official
    # six-view pipeline conditions on reference latents and consumes the base keys.
    wanted = unet.state_dict().keys()
    unet.load_state_dict({k:state[k] for k in wanted},strict=True,assign=True)
    unet.to(dtype)
    return HunyuanPaintPipeline(
        vae=AutoencoderKL.from_pretrained(root/"vae",torch_dtype=dtype),
        text_encoder=CLIPTextModel.from_pretrained(root/"text_encoder",torch_dtype=dtype),
        tokenizer=CLIPTokenizer.from_pretrained(root/"tokenizer"),
        unet=unet,scheduler=DDIMScheduler.from_pretrained(root/"scheduler"),
        feature_extractor=CLIPImageProcessor.from_pretrained(root/"feature_extractor"))

