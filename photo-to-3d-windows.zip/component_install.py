"""Prepare selected components in Blender's background Python, then start inference."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import traceback
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from component_catalog import (COMPONENTS, DATA, ENVIRONMENTS, SOURCES, U2NET_PATH,
                               components_for, missing_components, weight_files)
from download_file import fetch, valid_file
from model_weights import download_files
from state import ROOT, database, gpu_lock, jobdir, python_for, update


def artifact(name):
    item = SOURCES[name]
    target = ROOT / "installer" / name
    if valid_file(target, item["sha256"], item.get("size")):
        return target
    return fetch(item["url"], target, item["sha256"], item.get("size"))


def portable_python(stage):
    installer = ROOT / "installer"
    uv = installer / "uv.exe"
    python_dir = installer / "python"
    python = python_dir / "python.exe"
    if not uv.is_file():
        stage("Загрузка менеджера компонентов")
        with ZipFile(artifact("uv.zip")) as source:
            with source.open("uv.exe") as stream, uv.with_suffix(".part").open("wb") as output:
                shutil.copyfileobj(stream, output)
        uv.with_suffix(".part").replace(uv)
    if not python.is_file():
        stage("Загрузка Python 3.11")
        with tempfile.TemporaryDirectory(dir=installer) as tmp, tarfile.open(artifact("python.tar.gz")) as archive:
            archive.extractall(tmp, filter="data")
            extracted = Path(tmp) / "python"
            if not (extracted / "python.exe").is_file():
                raise ValueError("Архив Python не содержит python.exe")
            extracted.rename(python_dir)
    return uv, python


def patch_hunyuan(source):
    # Local Windows / low-VRAM changes for Tencent's pinned source revision.
    base = source / "hy3dgen/texgen"
    changes = {
        "differentiable_renderer/mesh_render.py": [
            ("import custom_rasterizer as cr", "# Photo3D: use the Windows rasterizer.\n            import hy_raster as cr"),
        ],
        "utils/dehighlight_utils.py": [
            ("self.pipeline = pipeline.to(self.device, torch.float16)",
             "self.pipeline = pipeline  # Photo3D: defer GPU transfer to CPU offload."),
        ],
        "utils/multiview_utils.py": [
            ("pipeline = DiffusionPipeline.from_pretrained(\n"
             "            multiview_ckpt_path,\n"
             "            custom_pipeline=custom_pipeline_path, torch_dtype=torch.float16)",
             "# Photo3D: load the local turbo Paint pipeline.\n"
             "        from hy_paint_load import load\n"
             "        pipeline = load(multiview_ckpt_path, torch.float16)"),
            ("self.pipeline = pipeline.to(self.device)", "self.pipeline = pipeline"),
            ("torch.Generator(device=self.pipeline.device)", "torch.Generator(device=self.device)"),
        ],
    }
    for relative, replacements in changes.items():
        path = base / relative
        text = path.read_text(encoding="utf-8")
        for original, replacement in replacements:
            if original not in text:
                raise ValueError(f"Не удалось применить изменения Windows к {relative}")
            text = text.replace(original, replacement, 1)
        path.write_text(text, encoding="utf-8")


def install_sources(engine, stage):
    stage(f"Загрузка кода {engine}")
    target = ROOT / engine / "src"
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=target.parent) as tmp:
        with ZipFile(artifact(engine + ".zip")) as archive:
            archive.extractall(tmp)
        source = next(Path(tmp).iterdir())
        if engine == "hunyuan":
            patch_hunyuan(source)
        shutil.copytree(source, target, dirs_exist_ok=True)
    return target


def setup_environment(engine, stage, launch):
    source = install_sources(engine, stage)
    uv, base_python = portable_python(stage)
    python = python_for(engine)
    env = {**os.environ, "UV_LINK_MODE": "copy", "UV_HTTP_TIMEOUT": "120", "UV_HTTP_RETRIES": "5"}
    env.setdefault("UV_CACHE_DIR", str(ROOT / "installer" / "uv-cache"))
    uv_command = [str(uv), "--no-config", "--no-progress"]
    stage(f"Подготовка окружения {engine}")
    venv = python.parent.parent
    repair = python.exists()
    launch([*uv_command, "venv", "--allow-existing", "--python", str(base_python), str(venv)], env)

    uv_install = [*uv_command, "pip", "install", "--no-deps", "--python", str(python)]
    if repair:
        uv_install.append("--reinstall")
    stage("Загрузка PyTorch и CUDA 12.8")
    torch_packages = ["torch==2.8.0+cu128", "torchvision==0.23.0+cu128"]
    if engine == "trellis":
        torch_packages.append("xformers==0.0.32.post2")
    launch([*uv_install, "--index-url", "https://download.pytorch.org/whl/cu128", *torch_packages], env)
    stage(f"Установка библиотек {engine}")
    launch([*uv_install, "--index-url", "https://pypi.org/simple", "-r", str(DATA / (engine + ".txt"))], env)
    if engine == "trellis":
        wheels = sorted((source / "whl").glob("*.whl"))
    else:
        wheels = [artifact("nvdiffrast-0.4.0-cp311-cp311-win_amd64.whl")]
    launch([*uv_install, *map(str, wheels)], env)
    stage("Проверка PyTorch и видеокарты")
    probe = ("import torch,torchvision,nvdiffrast.torch; "
             "import cumesh,flex_gemm,xformers" if engine == "trellis"
             else "import torch,torchvision,rembg,nvdiffrast.torch,pymeshlab")
    probe += "; assert torch.cuda.is_available(), 'CUDA unavailable; check NVIDIA driver'; print(torch.cuda.get_device_name())"
    try:
        launch([str(python), "-c", probe], env)
    except RuntimeError as exc:
        raise RuntimeError("Проверка Python/CUDA не прошла. Подробности в run.log") from exc


def install_component(component, stage, launch):
    stage("Установка · " + COMPONENTS[component])
    if component in ENVIRONMENTS:
        setup_environment(component.removesuffix("_env"), stage, launch)
    elif component == "u2netp":
        path = ROOT / U2NET_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        artifact("u2netp.onnx").replace(path)
    else:
        download_files(ROOT, weight_files(component), stage)


def run(job_id):
    worker = Path(__file__).with_name("worker.py").resolve()
    with gpu_lock() as free:
        if not free:
            return
        with database() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM jobs WHERE status='waiting' ORDER BY id LIMIT 1").fetchone()
            if not row or row["id"] != job_id:
                return
            db.execute("UPDATE jobs SET status='running',note='Проверка компонентов' WHERE id=?", (job_id,))
        start = time.monotonic()
        stop = threading.Event()
        child = None

        def stage(message):
            print(message, flush=True)
            with database() as db:
                db.execute("UPDATE jobs SET note=? WHERE id=?", (message, job_id))

        def launch(args, env):
            nonlocal child
            child = subprocess.Popen(args, env=env, stdout=sys.stdout, stderr=subprocess.STDOUT,
                                     creationflags=subprocess.CREATE_NO_WINDOW)
            code = child.wait()
            if code:
                raise RuntimeError(f"Установка прервалась с кодом {code}. Подробности в run.log")
            child = None

        def watch():
            while not stop.wait(0.4):
                with database() as db:
                    row = db.execute("SELECT status FROM jobs WHERE id=?", (job_id,)).fetchone()
                if row and row["status"] == "cancelling":
                    current = child
                    if current is not None and current.poll() is None:
                        subprocess.run(["taskkill", "/PID", str(current.pid), "/T", "/F"],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                       creationflags=subprocess.CREATE_NO_WINDOW)
                    update(job_id, "cancelled", "Установка отменена", time.monotonic() - start)
                    os._exit(2)

        threading.Thread(target=watch, daemon=True).start()
        try:
            spec = json.loads(row["spec"])
            requested = components_for(spec)
            absent = missing_components(ROOT, requested)
            if absent and not (spec.get("allow_setup") or spec.get("action") == "setup"):
                raise RuntimeError("Докачайте нужные компоненты во вкладке «Компоненты» или нажмите «Повторить»")
            for component in absent:
                install_component(component, stage, launch)
            if remaining := missing_components(ROOT, requested):
                raise RuntimeError("Проверьте установку · " + ", ".join(COMPONENTS[k] for k in remaining))
            with database() as db:
                status = db.execute("SELECT status FROM jobs WHERE id=?", (job_id,)).fetchone()["status"]
                if status == "cancelling":
                    db.execute("UPDATE jobs SET status='cancelled',note='Установка отменена' WHERE id=?", (job_id,))
                    return
                if spec.get("action") == "setup":
                    db.execute("UPDATE jobs SET status='done',note='Компоненты установлены',elapsed=? WHERE id=?",
                               (time.monotonic() - start, job_id))
                    return
                db.execute("UPDATE jobs SET status='waiting',note='Компоненты готовы' WHERE id=?", (job_id,))
        except Exception as error:
            traceback.print_exc()
            update(job_id, "error", str(error)[:450], time.monotonic() - start)
            return
        finally:
            stop.set()
    subprocess.run([str(python_for(spec["engine"])), "-u", str(worker), str(job_id)],
                   stdout=sys.stdout, stderr=subprocess.STDOUT,
                   creationflags=subprocess.CREATE_NO_WINDOW, check=True)


if __name__ == "__main__":
    run(int(sys.argv[sys.argv.index("--") + 1]))
