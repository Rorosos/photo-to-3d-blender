"""Download a pinned artifact with a resumable temporary file."""

import hashlib
from http.client import IncompleteRead
import shutil
import time
from urllib.error import URLError
from urllib.request import Request, urlopen


def valid_file(path, checksum, size=None):
    if not path.is_file() or (size is not None and path.stat().st_size != size):
        return False
    with path.open("rb") as stream:
        if checksum.startswith("git:"):
            digest = hashlib.sha1(f"blob {path.stat().st_size}\0".encode())
            return hashlib.file_digest(stream, lambda: digest).hexdigest() == checksum[4:]
        return hashlib.file_digest(stream, "sha256").hexdigest() == checksum


def fetch(url, target, checksum, size=None, token=None):
    target.parent.mkdir(parents=True, exist_ok=True)
    part = target.with_name(target.name + ".part")
    for attempt in range(4):
        length = part.stat().st_size if part.exists() else 0
        if size is not None and length >= size:
            if valid_file(part, checksum, size):
                part.replace(target)
                return target
            part.unlink()
            length = 0
        headers = {"Range": f"bytes={length}-"} if length else {}
        request = Request(url, headers=headers)
        if token:
            request.add_unredirected_header("Authorization", "Bearer " + token)
        try:
            with urlopen(request, timeout=120) as response:
                resume = response.status == 206
                if resume and not response.headers.get("Content-Range", "").startswith(f"bytes {length}-"):
                    raise ValueError("Сервер вернул неверный диапазон файла")
                with part.open("ab" if resume else "wb") as stream:
                    shutil.copyfileobj(response, stream, length=1024 * 1024)
        except (TimeoutError, ConnectionError, IncompleteRead, URLError) as exc:
            if attempt == 3 or getattr(exc, "code", None) in {401, 403, 404}:
                raise
            time.sleep(2 ** attempt)
            continue
        if valid_file(part, checksum, size):
            part.replace(target)
            return target
        if size is not None and part.stat().st_size < size and attempt < 3:
            continue
        part.unlink(missing_ok=True)
        raise ValueError(f"Контрольная сумма не совпала для {target.name}")
