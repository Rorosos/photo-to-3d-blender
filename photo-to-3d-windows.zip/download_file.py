"""Download a pinned artifact with a resumable temporary file."""

import hashlib
from http.client import IncompleteRead
import time
from urllib.error import URLError
from urllib.request import Request, urlopen


def valid_file(path, checksum, size=None):
    if not path.is_file() or (size is not None and path.stat().st_size != size):
        return False
    with path.open("rb") as stream:
        if checksum.startswith("git:"):
            digest = hashlib.sha1(f"blob {path.stat().st_size}\0".encode())
            return hashlib.file_digest(stream, lambda: digest).hexdigest() == checksum[4:]
        return hashlib.file_digest(stream, "sha256").hexdigest() == checksum


def fetch(url, target, checksum, size=None, token=None, progress=None):
    target.parent.mkdir(parents=True, exist_ok=True)
    part = target.with_name(target.name + ".part")
    for attempt in range(4):
        length = part.stat().st_size if part.exists() else 0
        if size is not None and length >= size:
            if valid_file(part, checksum, size):
                part.replace(target)
                if progress:
                    progress(size, size)
                return target
            part.unlink()
            length = 0
        headers = {"Range": f"bytes={length}-"} if length else {}
        request = Request(url, headers=headers)
        if token:
            request.add_unredirected_header("Authorization", "Bearer " + token)
        try:
            with urlopen(request, timeout=120) as response:
                resume = response.status == 206
                if resume and not response.headers.get("Content-Range", "").startswith(f"bytes {length}-"):
                    raise ValueError("Сервер вернул неверный диапазон файла")
                received = length if resume else 0
                content_length = response.headers.get("Content-Length", "")
                total = size or (received + int(content_length) if content_length.isdecimal() else None)
                last_update = time.monotonic()
                if progress:
                    progress(received, total)
                with part.open("ab" if resume else "wb") as stream:
                    while block := response.read(1024 * 1024):
                        stream.write(block)
                        received += len(block)
                        now = time.monotonic()
                        if progress and now - last_update >= 0.4:
                            progress(received, total)
                            last_update = now
        except (TimeoutError, ConnectionError, IncompleteRead, URLError) as exc:
            if attempt == 3 or getattr(exc, "code", None) in {401, 403, 404}:
                raise
            time.sleep(2 ** attempt)
            continue
        if valid_file(part, checksum, size):
            part.replace(target)
            if progress:
                progress(received, total)
            return target
        if size is not None and part.stat().st_size < size and attempt < 3:
            continue
        part.unlink(missing_ok=True)
        raise ValueError(f"Контрольная сумма не совпала для {target.name}")
