"""Hunyuan renderer's triangle IDs and three barycentric weights using nvdiffrast."""
import torch
import nvdiffrast.torch as dr

_context = None

def rasterize(pos, tri, resolution):
    global _context
    if _context is None:
        _context = dr.RasterizeCudaContext(device=pos.device)
    raster,_ = dr.rasterize(_context,pos.float().contiguous(),tri.int().contiguous(),list(resolution))
    r = raster[0]
    ids = r[...,3].int()
    weights = torch.stack((r[...,0],r[...,1],1-r[...,0]-r[...,1]),dim=-1)
    return ids, weights*(ids>0).unsqueeze(-1)

def interpolate(col, findices, barycentric, tri):
    idx = (findices.long()-1).clamp_min(0)
    return (col[0,tri.long()[idx]]*barycentric.unsqueeze(-1)).sum(dim=-2).unsqueeze(0)

